
export type PlayerId = 'N' | 'S';

export interface Character {
  name: string;
}

export type CustomIcons = Record<string, string>; // character name -> base64 string

export interface HistoryEntry {
  characterName: string;
  timestamp: number;
}
